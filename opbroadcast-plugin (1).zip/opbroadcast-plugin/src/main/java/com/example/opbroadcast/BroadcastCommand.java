package com.example.opbroadcast;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BroadcastCommand implements CommandExecutor {

    private final OpBroadcastPlugin plugin;

    public BroadcastCommand(OpBroadcastPlugin plugin) {
        this.plugin = plugin;
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private String msg(String key) {
        return plugin.getConfig().getString("messages." + key, key);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("opbroadcast.use")) {
            sender.sendMessage(color(msg("no-permission")));
            return true;
        }

        if (command.getName().equalsIgnoreCase("broadcast")) {
            return handleBroadcast(sender, args);
        } else if (command.getName().equalsIgnoreCase("vbroadcast")) {
            return handleVoiceBroadcast(sender, args);
        }
        return false;
    }

    private boolean handleBroadcast(CommandSender sender, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(color(msg("usage-broadcast")));
            return true;
        }
        String message = String.join(" ", args);
        String formatted = msg("broadcast-format")
                .replace("{sender}", sender.getName())
                .replace("{message}", message);
        Bukkit.broadcastMessage(color(formatted));

        String title = color(msg("broadcast-title"));
        String subtitle = color(msg("broadcast-subtitle")
                .replace("{sender}", sender.getName())
                .replace("{message}", message));
        plugin.showTitleToAll(title, subtitle);

        int freezeSeconds = plugin.getConfig().getInt("options.chat-freeze-seconds", 10);
        plugin.freezeChatFor(freezeSeconds);
        return true;
    }

    private boolean handleVoiceBroadcast(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(color("&cOnly players can use voice broadcast (it needs your mic)."));
            return true;
        }

        VoiceBroadcastHandler handler = plugin.getVoiceHandler();
        if (handler == null) {
            sender.sendMessage(color(msg("voicechat-not-installed")));
            return true;
        }

        if (args.length != 1 || !(args[0].equalsIgnoreCase("on") || args[0].equalsIgnoreCase("off"))) {
            sender.sendMessage(color(msg("usage-vbroadcast")));
            return true;
        }

        boolean on = args[0].equalsIgnoreCase("on");
        handler.setBroadcasting(player.getUniqueId(), on);
        sender.sendMessage(color(msg(on ? "voice-broadcast-on" : "voice-broadcast-off")));

        if (on) {
            plugin.freezeChatIndefinitely();
            String title = color(msg("voice-broadcast-title"));
            String subtitle = color(msg("voice-broadcast-subtitle").replace("{sender}", sender.getName()));
            plugin.startPersistentTitle(title, subtitle);
        } else {
            plugin.unfreezeChat();
            plugin.stopPersistentTitle();
        }
        return true;
    }
}
