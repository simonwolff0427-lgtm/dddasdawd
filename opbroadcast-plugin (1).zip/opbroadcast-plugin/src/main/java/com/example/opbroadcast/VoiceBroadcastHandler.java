package com.example.opbroadcast;

import de.maxhenkel.voicechat.api.VoicechatApi;
import de.maxhenkel.voicechat.api.VoicechatConnection;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.VoicechatServerApi;
import de.maxhenkel.voicechat.api.audiochannel.StaticAudioChannel;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.events.MicrophonePacketEvent;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Registers with Simple Voice Chat's plugin API. While a player is in
 * "broadcasting" mode (toggled via /vbroadcast on), any audio their mic sends
 * gets copied out to every other connected Voice Chat player directly, instead
 * of only the players within normal proximity range — so it's heard server-wide
 * by anyone who has the mod installed. Players without the mod simply can't
 * receive this at all; there's no protocol-level way around that, which is why
 * /broadcast (plain text) exists as the everyone-hears-it fallback.
 */
public class VoiceBroadcastHandler implements VoicechatPlugin {

    private final OpBroadcastPlugin plugin;
    private final Set<UUID> broadcasting = ConcurrentHashMap.newKeySet();
    private VoicechatServerApi api;

    // Reuse one outgoing channel per (broadcaster, listener) pair rather than
    // creating a new one for every single audio packet.
    private final Map<String, StaticAudioChannel> channels = new ConcurrentHashMap<>();

    public VoiceBroadcastHandler(OpBroadcastPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getPluginId() {
        return "opbroadcast";
    }

    @Override
    public void initialize(VoicechatApi api) {
        if (api instanceof VoicechatServerApi serverApi) {
            this.api = serverApi;
        }
    }

    @Override
    public void registerEvents(EventRegistration registration) {
        registration.registerEvent(MicrophonePacketEvent.class, this::onMicrophonePacket);
    }

    public void setBroadcasting(UUID playerId, boolean on) {
        if (on) {
            broadcasting.add(playerId);
        } else {
            broadcasting.remove(playerId);
        }
    }

    private void onMicrophonePacket(MicrophonePacketEvent event) {
        if (api == null) return;

        VoicechatConnection sender = event.getSenderConnection();
        if (sender == null) return;

        UUID senderId = sender.getPlayer().getUuid();
        if (!broadcasting.contains(senderId)) return;

        byte[] opusData = event.getPacket().getOpusEncodedData();
        if (opusData == null) return;

        for (VoicechatConnection connection : api.getConnections()) {
            UUID listenerId = connection.getPlayer().getUuid();
            if (listenerId.equals(senderId)) continue; // they hear their own mic locally already

            String key = senderId + ":" + listenerId;
            StaticAudioChannel channel = channels.computeIfAbsent(key,
                    k -> api.createStaticAudioChannel(UUID.randomUUID(), connection));
            if (channel != null) {
                channel.send(opusData);
            }
        }
    }
}
